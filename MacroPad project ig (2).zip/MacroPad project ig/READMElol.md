#today is 10th October 2026

# This is my Hack Club Stardance MicroPad

This is a custom mechanical MacroPad desinged for the stardance challenge 
It uses a RaspBerry Pi Pico and its running on CircuitPython

So far for my keys ive made:
Button 1: for Copying 
Button 2: for Pasting 
Button 3: This is for any custom emoji shortcut which I hope I can make fully customizable
Button 4: This is for muting ur mic on Dicord
Button 5: this is for taking screenshots
Button 6: this is just for playing any media or pausing it
Button 7: For increasing ur volume 
Button 8: for lowering ur volume 
Button 9: for minimizing everything on ur desktop
Button 10: for closing ur web browser
Button 11: force closing ur game or window
Button 12: basically for undoing an action

I hope I can get customizable keycaps (Would be soooooo cooooll!!!!)




