import time 
import board 
import digitalio
import usb_hid
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control import ConsumerControlCode
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard import Keycode
cc = ConsumerControl(usb_hid.devices)

kbd = Keyboard(usb_hid.services)
pins = [board.GP1 , board.GP2 , board.GP3 , board.GP4 , board.GP5 , board.GP6 , board.GP7 , board.GP8 , board.GP9 , board.GP10 , board.GP11 , board.GP12]
switches = []

for pin in pins :
    switch = digitalio.DigitalInOut(pin)
    switch.direction = digitalio.Direction.INPUT
    switch.pull = digitalio.Pull.UP
    switches.append(switch)

print ("MacroPad Ready!")

while True: 

    if not switches[0].value:
        kbd.send(Keycode.CONTROL , Keycode.C) #This is for copying
        time.sleep(0.2)

    if not switches[1].value:
        kbd.send(Keycode.CONTROL , Keycode.V) #This is for pasting
        time.sleep(0.2)

    if not switches[2].value:
        kbd.send(Keycode.CONTROL , Keycode.M)#This can be customized to any command

    if not switches[3].value:
        kbd.send(Keycode.CONTROL , Keycode.SHIFT , Keycode.M)#This is for muting ur mic on Disocrd
        time.sleep(0.2)

    if not switches [4].value:
        kbd.send(Keycode.GUI , Keycode.SHIFT , Keycode.S)  # GUI is the windows/Command key . Its for Screenshotting 
        time.sleep(0.2)

    if not switches[5].value:
        print("Media Play/Pause Triggered")#This is for playing and pausing media 
        time.sleep(0.2)

    if not switches[6].value:
        cc.send(ConsumerControlCode.VOLUME_INCREMENT)#This is for Turning up ur system volume
        time.sleep(0.15)

    if not switches[7].value:
        cc.send(ConsumerControlCode.VOLUME_DECREMENT)#This is for turning dowm ur system volume 
        time.sleep(0.15)

    if not switches[8].value:
        kbd.send(Keycode.GUI , Keycode.D)#This i'd like to call is the "Ultimate key" because it minimizes everyting on ur desktop
        time.sleep(0.3)

    if not switches[9].value:
        kbd.send(Keycode.CONTROL, Keycode.W)#This is for instantly closing the web browser ur looking at
        time.sleep(0.3)

    if not switches[10].value:
        kbd.send(Keycode.ALT, Keycode.F4)#This force closes ur active game or window to shut down or close instantly 
        time.sleep(0.3)

    if not switches[11].value:
        kbd.send(Keycode.CONTROL, Keycode.SHIFT, Keycode.T)#This is for undoing an accident that u may have done (basically ctrl+z)
        time.sleep(0.3)

    time.sleep(0.1)

#We can use Keycode.M to make a 
# dedicated Mute button or maybe we can use Keycode.V to paste and 
# really theres endless possibilities with coding.